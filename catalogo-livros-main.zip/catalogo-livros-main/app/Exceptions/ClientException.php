<?php

namespace App\Exceptions;

/**
 * Thrown when an exception occurs from the API client.
 */
class ClientException extends HTTPException
{

}