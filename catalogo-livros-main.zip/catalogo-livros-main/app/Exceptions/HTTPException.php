<?php

namespace App\Exceptions;

use RuntimeException;

/**
 * Thrown when an HTTP exception occurs.
 */
class HTTPException extends RuntimeException
{

}